/********************** SIGN UP SETTING **********************/  
const EMAIL_VERIFICATION_TIME: number = 15 
const INITIAL_PROFILE_IMAGE: string = "/newbie.png"


/*************************************************************/

export {
    EMAIL_VERIFICATION_TIME,
    INITIAL_PROFILE_IMAGE 
}