interface QueryResult {
    type: string;
    message: string;
}

export {
    QueryResult
}