export type EmailCheckResult = { email: string } | undefined;
export type PromoCodeCheckResult = { promo_code: string } | undefined;
export type AuthCodeCheckResult = { auth_code: string } | undefined;
export type ApiKeyCheckResult = { api_key: string} | undefined;
export type AffiliateCodeResult = { affiliate_code: string} | undefined;
export type memberResult = any