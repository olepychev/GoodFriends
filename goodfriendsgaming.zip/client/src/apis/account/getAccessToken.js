import axios from 'axios';

const GF_API_KEY = import.meta.env.VITE_GF_API_KEY;
const GF_AFFILIATE_CODE = import.meta.env.VITE_GF_AFFILIATE_CODE;
const SEVER_URL = import.meta.env.VITE_SEVER_URL;

export const getAccessToken = async () => {
	const responseBody = (response) => response.data;

	const { data } = await axios.post(SEVER_URL + '/api/account/sign-in/success', {}, {
		headers: {
			'GF-API-KEY': GF_API_KEY,
			'GF-AFFILIATE-CODE': GF_AFFILIATE_CODE,
			'Content-Type': 'application/json'
		},
		withCredentials: true
	}).then(responseBody);
	
	console.log('bbbbbbbbb', data)
	return data;
}
