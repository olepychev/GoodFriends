<div class="container">
    <div class="mobilenone">
      <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="#">Home</a></li>
          <li class="breadcrumb-item active" aria-current="page">Sports</li>
        </ol>
      </nav>
    </div>
    <div class="sportb desknone favourites">
    <div class="row mb-3">
        <div class="col-2 pe-0">
          <button type="button" class="btn btn-search w-100">
            <img src="/img/Group-48.svg" />
          </button>
        </div>
        <div class="col-10 ps-0">
          <div class="form-outline">
            <input type="search" id="form1" class="form-control w-100" placeholder="Search" />
          </div>
        </div>
      </div>
      <div class="boxthird desknone">
        <button class="btn">
          <img class="me-1" src="/img/soccer-ball.svg" /> Sports A-Z
        </button>
        <button class="btn">
          <img class="me-1" src="/img/esports.svg" /> Favorites
        </button>
        <button class="btn">
          <img class="me-1" src="/img/esports.svg" /> Payback
        </button>
      </div>
    </div>
    <div class="sports">
      <div class="box">
        <div class="sports_img sports-exapanded1">
          <img class="w-100 main mobilenone" src="/img/Banner_Football.svg" />
          <img class="w-100 main desknone" src="/img/sports-mobile.svg" />
          <!-- <div class="overlay"></div> -->
          <div class="text-content">
            <h1>Soccer Odds</h1>
            <a href="/sports" class="me-5">Hightlights</a>
            <a href="#" class="me-5">Live</a>
            <a href="#" class="hightlight me-5">Leagues</a>
          </div>
        </div>
        <div class="content pt-1"></div>
      </div>
    </div>
    <div class="leagues mt-3">
      <h3 class="mb-0">Top Leagues</h3>
      <p class="mb-0">
        Englad - FA Cup <span>(3)</span>
        <svg class="favorite-league float-end active"><use href="/img/symbols.svg?lang.svg#icon_star" /></svg>
      </p>
      <p class="mb-0">
        England - Premier League Odds <span>(15)</span>
        <svg class="favorite-league float-end"><use href="/img/symbols.svg?lang.svg#icon_star" /></svg>
      </p>
      <p class="mb-0">
        Italy - Serie A Odds <span>(10)</span>
        <svg class="favorite-league float-end"><use href="/img/symbols.svg?lang.svg#icon_star" /></svg>
      </p>
      <p class="mb-0">
        Spain - La Liga Odds <span>(25)</span>
        <svg class="favorite-league float-end"><use href="/img/symbols.svg?lang.svg#icon_star" /></svg>
      </p>
      <h4 class="mb-0 mt-4"><span>A</span></h4>
      <p class="mb-0">
        Englad - FA Cup <span>(3)</span>
        <svg class="favorite-league float-end"><use href="/img/symbols.svg?lang.svg#icon_star" /></svg>
      </p>
      <p class="mb-0">
        England - Premier League Odds <span>(15)</span>
        <svg class="favorite-league float-end"><use href="/img/symbols.svg?lang.svg#icon_star" /></svg>
      </p>
      <p class="mb-0">
        Italy - Serie A Odds <span>(10)</span>
        <svg class="favorite-league float-end"><use href="/img/symbols.svg?lang.svg#icon_star" /></svg>
      </p>
      <p class="mb-0">
        Spain - La Liga Odds <span>(25)</span>
        <svg class="favorite-league float-end"><use href="/img/symbols.svg?lang.svg#icon_star" /></svg>
      </p>
      <p class="mb-0">
        Englad - FA Cup <span>(3)</span>
        <svg class="favorite-league float-end"><use href="/img/symbols.svg?lang.svg#icon_star" /></svg>
      </p>
      <p class="mb-0">
        England - Premier League Odds <span>(15)</span>
        <svg class="favorite-league float-end"><use href="/img/symbols.svg?lang.svg#icon_star" /></svg>
      </p>
      <p class="mb-0">
        Italy - Serie A Odds <span>(10)</span>
        <svg class="favorite-league float-end"><use href="/img/symbols.svg?lang.svg#icon_star" /></svg>
      </p>
      <p class="mb-0">
        Spain - La Liga Odds <span>(25)</span>
        <svg class="favorite-league float-end"><use href="/img/symbols.svg?lang.svg#icon_star" /></svg>
      </p>
      <h4 class="mb-0 mt-4"><span>B</span></h4>
      <p class="mb-0">
        Englad - FA Cup <span>(3)</span>
        <svg class="favorite-league float-end"><use href="/img/symbols.svg?lang.svg#icon_star" /></svg>
      </p>
      <p class="mb-0">
        England - Premier League Odds <span>(15)</span>
        <svg class="favorite-league float-end"><use href="/img/symbols.svg?lang.svg#icon_star" /></svg>
      </p>
      <p class="mb-0">
        Italy - Serie A Odds <span>(10)</span>
        <svg class="favorite-league float-end"><use href="/img/symbols.svg?lang.svg#icon_star" /></svg>
      </p>
      <p class="mb-0">
        Italy - Serie A Odds <span>(10)</span>
        <svg class="favorite-league float-end"><use href="/img/symbols.svg?lang.svg#icon_star" /></svg>
      </p>
      <p class="mb-0">
        Spain - La Liga Odds <span>(25)</span>
        <svg class="favorite-league float-end"><use href="/img/symbols.svg?lang.svg#icon_star" /></svg>
      </p>
      <h4 class="mb-0 mt-4"><span>C</span></h4>
      <p class="mb-0">
        Englad - FA Cup <span>(3)</span>
        <svg class="favorite-league float-end"><use href="/img/symbols.svg?lang.svg#icon_star" /></svg>
      </p>
      <p class="mb-0">
        England - Premier League Odds <span>(15)</span>
        <svg class="favorite-league float-end"><use href="/img/symbols.svg?lang.svg#icon_star" /></svg>
      </p>
      <h4 class="mb-0 mt-4"><span>D</span></h4>
      <p class="mb-0">
        Englad - FA Cup <span>(3)</span>
        <svg class="favorite-league float-end"><use href="/img/symbols.svg?lang.svg#icon_star" /></svg>
      </p>
      <p class="mb-0">
        England - Premier League Odds <span>(15)</span>
        <svg class="favorite-league float-end"><use href="/img/symbols.svg?lang.svg#icon_star" /></svg>
      </p>
      <p class="mb-0">
        Italy - Serie A Odds <span>(10)</span>
        <svg class="favorite-league float-end"><use href="/img/symbols.svg?lang.svg#icon_star" /></svg>
      </p>
      <p class="mb-0">
        Spain - La Liga Odds <span>(25)</span>
        <svg class="favorite-league float-end"><use href="/img/symbols.svg?lang.svg#icon_star" /></svg>
      </p>
      <p class="mb-0">
        Englad - FA Cup <span>(3)</span>
        <svg class="favorite-league float-end"><use href="/img/symbols.svg?lang.svg#icon_star" /></svg>
      </p>
      <p class="mb-0">
        England - Premier League Odds <span>(15)</span>
        <svg class="favorite-league float-end"><use href="/img/symbols.svg?lang.svg#icon_star" /></svg>
      </p>
      <p class="mb-0">
        Italy - Serie A Odds <span>(10)</span>
        <svg class="favorite-league float-end"><use href="/img/symbols.svg?lang.svg#icon_star" /></svg>
      </p>
      <p class="mb-0">
        Spain - La Liga Odds <span>(25)</span>
        <svg class="favorite-league float-end"><use href="/img/symbols.svg?lang.svg#icon_star" /></svg>
      </p>
    </div>
  </div>