<script>

</script>
	
<div class="slip-item">
		<div class="slip-item-inner">
				<div class="slip-remove">
						<svg><use href="/img/symbols.svg?lang.svg#icon_modal_close"/></svg>
				</div>
				<div class="team-info">
						<img src="/img/basketball.svg" alt="">
						<span class="team1">Memphis1</span><span> - </span>
						<span class="team2">Houston</span>
				</div>
				<div class="odd-type"><span>Handicap - Game - NCAA</span></div>
				<div class="odd-detail">
						<span class="selected-odd">Memphis +12.0</span>
						<span class="slip-item-rate">1.425</span>
				</div>
				<div class="slip-item-input-wrapper">
						<div class="input-item">
								<input type="text">
								<span>Bet</span>
						</div>
						<div class="input-item">
								<input type="text">
								<span>Win</span>
						</div>                                        
				</div>
		</div>
</div>